drop database if exists Grade_db;

create database Grade_db;

use Grade_db;

create table Grade(
	번호 int,
	이름 varchar(50),
    국어 varchar(50),
    영어 varchar(50),
    수학 varchar(50),
	primary key(번호)
);


insert into Grade values (1,'이름1','10','20','30');
insert into Grade values (2,'이름2','20','40','30');





select * from Grade;