package grade;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class GradeDAO {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
		
	//		---------- DB���� ----------  //
	public GradeDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/Grade_db";//mysql ��ġ
			String dbID = "root";//mysql ID
			String dbPassword = "root";//mysql PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");//���� ����̹�
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);//DB�������� �� ����
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//�ڵ����� ��ȣ
	public int getNext() {
		String SQL = "SELECT ��ȣ FROM Grade ORDER BY ��ȣ DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}else {
				return 1;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//����
	}
		
	//������
	public int write(Integer Number, String Name, String Kor, String Eng, String Math) {
		String SQL = "INSERT INTO Grade VALUES(?,?,?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, Name);
			pstmt.setString(3, Kor);
			pstmt.setString(4, Eng);
			pstmt.setString(5, Math);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//�����ͺ��̽� ����
	}


		
	//���
	public ArrayList<Grade> getList(){
		String SQL = "SELECT * FROM Grade ORDER BY ��ȣ";                        
		ArrayList<Grade> list = new ArrayList<Grade>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Grade grade = new Grade();
				grade.setNumber(rs.getInt(1));
				grade.setName(rs.getString(2));
				grade.setKor(rs.getString(3));
				grade.setEng(rs.getString(4));
				grade.setMath(rs.getString(5));
				list.add(grade);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	//�����б�
	 public Grade getGrade(int Number) {
		 String SQL = "SELECT * FROM Grade WHERE ��ȣ = ?";
		 try {
				PreparedStatement pstmt=conn.prepareStatement(SQL);
				pstmt.setInt(1, Number);
				rs=pstmt.executeQuery();
				if(rs.next()) {
					Grade grade = new Grade();
					grade.setNumber(rs.getInt(1));
					grade.setName(rs.getString(2));
					grade.setKor(rs.getString(3));
					grade.setEng(rs.getString(4));
					grade.setMath(rs.getString(5));
					return grade;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		 return null;
	 }
	 

}



